public class Nodo {
		Nodo link0;
		Nodo link1;
		String Nome;
		String Fone;
}